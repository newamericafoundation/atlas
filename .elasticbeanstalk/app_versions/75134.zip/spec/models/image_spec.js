var assert = require('assert'),
	_ = require('underscore'),
	Backbone = require('backbone'),
	$ = require('jquery'),
	image = require('./../../app/models/image.js');


describe('image.Model', function() {

	var model;

});