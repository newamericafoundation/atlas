## Testing Environment

Client- and server-side specs are run with the following commands:

	gulp spec